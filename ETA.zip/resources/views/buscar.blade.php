<!DOCTYPE html>
<html>
<head>
    <title>Buscar Personas</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    var nombres = 
    [@foreach ($refugiados as $refugiado)
     "{{$refugiado->nombre}}",
    @endforeach
    ];
    $( "#nombre" ).autocomplete({
      source: nombres
    });
  } );
  </script>
</head>
<body>
<div class="container mt-4">
  @if($status)
    <div class="alert alert-success">
        {{ $status}}
    </div>
  @endif
  <div class="card">
    <div class="card-header text-center font-weight-bold">
      Buscar Persona
    </div>
    <div class="card-body">
      <form name="add-blog-post-form" id="add-blog-post-form" method="post" action="{{url('buscar')}}">
       @csrf
        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input type="text" id="nombre" name="nombre" class="form-control" required="">
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>

        @if ($personas)
        @foreach($personas as $persona)
        <br>
        <strong>REFUGIADO ENCONTRADO</strong>
        <div class="form-group">
          <label for="nombre">Nombre:{{$persona->nombre}}</label>
        </div>
        @if($persona->identidad)
        <div class="form-group">
          <label for="identidad">Indentidad:{{$persona->identidad}}</label>
        </div>
        @endif
        @if($persona->edad)
        <div class="form-group">
          <label for="edad">Edad:{{$persona->edad}}</label>
        </div>
        @endif
        @if($persona->telefono)
        <div class="form-group">
          <label for="telefono">Teléfono:{{$persona->telefono}}</label>
        </div>
        @endif
        @if($persona->refugio->departamento->departamento)
        <div class="form-group">
          <label for="departamento">Departamento: {{$persona->refugio->departamento->departamento}}</label>
        </div>
        @endif
        @if($persona->refugio->nombre)
        <div class="form-group">
          <label for="refugios_id">Refugio: {{$persona->refugio->nombre}}</label>
        </div>
        @endif
        @endforeach
        @endif
      </form>
    </div>
  </div>
</div>    
</body>
</html>