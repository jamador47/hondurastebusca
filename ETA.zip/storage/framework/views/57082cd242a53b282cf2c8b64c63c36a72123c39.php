<!DOCTYPE html>
<html>
<head>
    <title>Buscar Personas</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    var nombres = 
    [<?php $__currentLoopData = $refugiados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refugiado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     "<?php echo e($refugiado->nombre); ?>",
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];
    $( "#nombre" ).autocomplete({
      source: nombres
    });
  } );
  </script>
</head>
<body>
<div class="container mt-4">
  <?php if($status): ?>
    <div class="alert alert-success">
        <?php echo e($status); ?>

    </div>
  <?php endif; ?>
  <div class="card">
    <div class="card-header text-center font-weight-bold">
      Buscar Persona
    </div>
    <div class="card-body">
      <form name="add-blog-post-form" id="add-blog-post-form" method="post" action="<?php echo e(url('buscar')); ?>">
       <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input type="text" id="nombre" name="nombre" class="form-control" required="">
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>

        <?php if($personas): ?>
        <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <strong>REFUGIADO ENCONTRADO</strong>
        <div class="form-group">
          <label for="nombre">Nombre:<?php echo e($persona->nombre); ?></label>
        </div>
        <?php if($persona->identidad): ?>
        <div class="form-group">
          <label for="identidad">Indentidad:<?php echo e($persona->identidad); ?></label>
        </div>
        <?php endif; ?>
        <?php if($persona->edad): ?>
        <div class="form-group">
          <label for="edad">Edad:<?php echo e($persona->edad); ?></label>
        </div>
        <?php endif; ?>
        <?php if($persona->telefono): ?>
        <div class="form-group">
          <label for="telefono">Teléfono:<?php echo e($persona->telefono); ?></label>
        </div>
        <?php endif; ?>
        <?php if($persona->refugio->departamento->departamento): ?>
        <div class="form-group">
          <label for="departamento">Departamento: <?php echo e($persona->refugio->departamento->departamento); ?></label>
        </div>
        <?php endif; ?>
        <?php if($persona->refugio->nombre): ?>
        <div class="form-group">
          <label for="refugios_id">Refugio: <?php echo e($persona->refugio->nombre); ?></label>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </form>
    </div>
  </div>
</div>    
</body>
</html><?php /**PATH C:\Users\Jossué\Desktop\ETA\ETA\resources\views/buscar.blade.php ENDPATH**/ ?>