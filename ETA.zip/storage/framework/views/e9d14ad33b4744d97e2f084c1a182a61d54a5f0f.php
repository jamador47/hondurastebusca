<!DOCTYPE html>
<html>
<head>
    <title>Agregar Refugio</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <?php if($status): ?>
    <div class="alert alert-success">
        <?php echo e($status); ?>

    </div>
  <?php endif; ?>
  <div class="card">
    <div class="card-header text-center font-weight-bold">
      Agregar Refugio
    </div>
    <div class="card-body">
      <form name="add-blog-post-form" id="add-blog-post-form" method="post" action="<?php echo e(url('agregarrefugio')); ?>">
       <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input type="text" id="nombre" name="nombre" class="form-control" required="">
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Departamento</label>
          <select name="departamentos_id" class="form-control" required="">
          <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($departamento->id); ?>"><?php echo e($departamento->departamento); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>
  
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
</div>    
</body>
</html><?php /**PATH C:\Users\Jossué\Desktop\ETA\ETA\resources\views/addrefugio.blade.php ENDPATH**/ ?>